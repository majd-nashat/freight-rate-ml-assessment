"""Loading and cleaning."""
import pandas as pd

from .config import RPM_MAX, RPM_MIN, TRAIN_FILE, VALIDATION_FILE


def load_raw():
    train = pd.read_csv(TRAIN_FILE, parse_dates=["date"])
    val = pd.read_csv(VALIDATION_FILE, parse_dates=["date"])
    return train, val


def fit_cleaning_params(train: pd.DataFrame) -> dict:
    """Statistics that must come from the training data only."""
    return {"weight_median": float(train["weight"].abs().median())}


def clean_features(df: pd.DataFrame, params: dict) -> pd.DataFrame:
    """Applied identically to train and validation.

    - weight: negative values are sign-entry errors -> absolute value;
      missing values -> training median.
    - market_index: missing values -> median of the same day (kept for EDA/ablation).
    """
    df = df.copy()
    df["weight"] = df["weight"].abs().fillna(params["weight_median"])
    daily = df.groupby("date")["market_index"].transform("median")
    df["market_index"] = df["market_index"].fillna(daily)
    return df


def add_target_columns(train: pd.DataFrame) -> pd.DataFrame:
    train = train.copy()
    train["rate_per_mile"] = train["posted_rate"] / train["distance"]
    train["is_target_outlier"] = (train["rate_per_mile"] < RPM_MIN) | (train["rate_per_mile"] > RPM_MAX)
    return train
