"""Train the final model on all labeled data and write the submission files.

Run:  python -m src.predict
Outputs: validation_predictions.csv, data/december_chart_inputs.csv (predicted_rate filled)
"""
import numpy as np
import pandas as pd

from .config import DECEMBER_FILE, ROOT, TEMPLATE_FILE
from .data import add_target_columns, clean_features, fit_cleaning_params, load_raw
from .features import build_features, city_coordinates
from .model import RateModel


def main():
    train_raw, val_raw = load_raw()
    params = fit_cleaning_params(train_raw)

    train = add_target_columns(clean_features(train_raw, params))
    val = clean_features(val_raw, params)

    # --- final model: all labeled data, minus implausible target values -----------
    fit_mask = ~train["is_target_outlier"]
    print(f"training rows: {fit_mask.sum():,} of {len(train):,} "
          f"({(~fit_mask).sum()} target outliers excluded)")
    model = RateModel().fit(build_features(train)[fit_mask], train.loc[fit_mask, "rate_per_mile"])

    # --- validation predictions ---------------------------------------------------
    val_pred = model.predict_rate(build_features(val), val["distance"])
    template = pd.read_csv(TEMPLATE_FILE)
    pred_by_id = pd.Series(val_pred, index=val["load_id"])
    template["predicted_rate"] = template["load_id"].map(pred_by_id).round(2)
    assert template["predicted_rate"].notna().all() and (template["predicted_rate"] > 0).all()
    template[["load_id", "predicted_rate"]].to_csv(ROOT / "validation_predictions.csv", index=False)
    print("wrote validation_predictions.csv", template.shape)

    # --- December chart -----------------------------------------------------------
    dec = pd.read_csv(DECEMBER_FILE)
    coords = city_coordinates(train_raw, val_raw)
    dec_feat = dec.copy()
    dec_feat["date"] = pd.to_datetime(dec_feat["date"])
    dec_feat["pickup_lat"] = dec_feat["pickup"].map(coords["lat"])
    dec_feat["pickup_lon"] = dec_feat["pickup"].map(coords["lon"])
    dec_feat["delivery_lat"] = dec_feat["delivery"].map(coords["lat"])
    dec_feat["delivery_lon"] = dec_feat["delivery"].map(coords["lon"])
    dec["predicted_rate"] = model.predict_rate(build_features(dec_feat), dec["distance"]).round(2)
    dec.to_csv(DECEMBER_FILE, index=False)
    print("wrote", DECEMBER_FILE.name, dec.shape)


if __name__ == "__main__":
    main()
