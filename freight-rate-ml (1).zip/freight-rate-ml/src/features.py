"""Feature engineering. Only columns available for every prediction set are used."""
import pandas as pd

from .config import EQUIPMENT_CODES


def city_coordinates(*frames: pd.DataFrame) -> pd.DataFrame:
    """City -> (lat, lon) lookup built from the provided data (needed for the December file)."""
    parts = []
    for f in frames:
        parts.append(f[["pickup", "pickup_lat", "pickup_lon"]].set_axis(["city", "lat", "lon"], axis=1))
        parts.append(f[["delivery", "delivery_lat", "delivery_lon"]].set_axis(["city", "lat", "lon"], axis=1))
    return pd.concat(parts).drop_duplicates("city").set_index("city")


def build_features(df: pd.DataFrame) -> pd.DataFrame:
    out = pd.DataFrame(index=df.index)
    out["distance"] = df["distance"].astype(float)
    out["equipment_code"] = df["equipment"].map(EQUIPMENT_CODES)
    out["weight"] = df["weight"].astype(float)
    out["pickup_lat"] = df["pickup_lat"]
    out["pickup_lon"] = df["pickup_lon"]
    out["delivery_lat"] = df["delivery_lat"]
    out["delivery_lon"] = df["delivery_lon"]
    out["day_of_week"] = df["date"].dt.dayofweek
    return out
