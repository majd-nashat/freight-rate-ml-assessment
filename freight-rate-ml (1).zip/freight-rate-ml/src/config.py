"""Shared constants for the freight-rate pipeline."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = ROOT / "data"
RESULTS_DIR = ROOT / "results"

TRAIN_FILE = DATA_DIR / "train_test.csv"
VALIDATION_FILE = DATA_DIR / "validation.csv"
TEMPLATE_FILE = DATA_DIR / "validation_predictions_template.csv"
DECEMBER_FILE = DATA_DIR / "december_chart_inputs.csv"

EQUIPMENT_CODES = {"Dry Van": 0, "Flatbed": 1, "Reefer": 2}

# Rate-per-mile range used to flag implausible target values (training only).
RPM_MIN, RPM_MAX = 1.0, 5.0

# Final feature set. `quote_signal` and `market_index` are deliberately excluded
# (see report / notebooks/01_eda.ipynb and validate.py for the ablation).
FEATURES = [
    "distance", "equipment_code", "weight",
    "pickup_lat", "pickup_lon", "delivery_lat", "delivery_lon",
    "day_of_week",
]

LGB_PARAMS = dict(
    objective="huber",
    n_estimators=400,
    learning_rate=0.05,
    num_leaves=15,
    min_child_samples=40,
    subsample=0.8,
    subsample_freq=1,
    colsample_bytree=0.9,
    verbose=-1,
    n_jobs=1,
)
SEEDS = [0, 1, 2, 3, 4]
