"""Model: LightGBM on log(rate per mile), averaged over several seeds."""
import lightgbm as lgb
import numpy as np

from .config import FEATURES, LGB_PARAMS, SEEDS


class RateModel:
    def __init__(self, features=None, params=None, seeds=None):
        self.features = features or FEATURES
        self.params = {**LGB_PARAMS, **(params or {})}
        self.seeds = seeds or SEEDS
        self.models = []

    def fit(self, X, rate_per_mile):
        y = np.log(rate_per_mile)
        self.models = [
            lgb.LGBMRegressor(**self.params, random_state=s).fit(X[self.features], y)
            for s in self.seeds
        ]
        return self

    def predict_rate(self, X, distance):
        log_rpm = np.mean([m.predict(X[self.features]) for m in self.models], axis=0)
        return np.exp(log_rpm) * np.asarray(distance)
