"""Time-based validation of the modeling choices.

Why time-based? validation.csv (Nov-Dec 2025) lies after all training data, so the
real task is forecasting. Each fold trains on the past and tests on the following
months (expanding window). A random split is also reported to show how optimistic
it would be.

Run:  python -m src.validate
"""
import numpy as np
import pandas as pd

from .config import FEATURES, RESULTS_DIR, RPM_MAX, RPM_MIN
from .data import add_target_columns, clean_features, fit_cleaning_params, load_raw
from .features import build_features
from .metrics import regression_metrics
from .model import RateModel

# (last training month, test months)
FOLDS = [(4, [5, 6]), (6, [7, 8]), (8, [9, 10])]
BANDS = [0, 100, 150, 200, 250, 300, 400, 500, 600, 800, 1000, 1250, 1500, 2000, 2500, 4000]

VARIANTS = {
    "final (no market_index, no quote_signal)": FEATURES,
    "+ market_index": FEATURES + ["market_index"],
    "+ quote_signal": FEATURES + ["quote_signal"],
    "+ market_index + quote_signal": FEATURES + ["market_index", "quote_signal"],
}


def baseline_predict(train_part, test_part):
    """Median rate per mile by distance band x equipment."""
    tp = train_part.assign(band=pd.cut(train_part["distance"], BANDS))
    med = tp.groupby(["band", "equipment"], observed=True)["rate_per_mile"].median()
    fallback = train_part["rate_per_mile"].median()
    bands = pd.cut(test_part["distance"], BANDS)
    rpm = [med.get((b, e), fallback) for b, e in zip(bands, test_part["equipment"])]
    return np.asarray(rpm) * test_part["distance"].values


def evaluate(test_part, pred, fold, variant, rows):
    clean_mask = ~test_part["is_target_outlier"].values
    for subset, mask in (("all rows", np.ones(len(test_part), bool)), ("clean rows", clean_mask)):
        m = regression_metrics(test_part["posted_rate"].values[mask], pred[mask])
        rows.append({"fold": fold, "variant": variant, "subset": subset, **m})


def build_frame():
    train, val = load_raw()
    params = fit_cleaning_params(train)
    train = add_target_columns(clean_features(train, params))
    feats = build_features(train)
    feats["market_index"] = train["market_index"]
    feats["quote_signal"] = train["quote_signal"]
    return train, feats


def main():
    train, feats = build_frame()
    month = train["date"].dt.month
    rows = []

    for last_train, test_months in FOLDS:
        fold = f"train Jan-{last_train:02d} -> test {test_months[0]:02d}-{test_months[-1]:02d}"
        tr_mask = (month <= last_train) & ~train["is_target_outlier"]
        te_mask = month.isin(test_months)
        te = train[te_mask]

        evaluate(te, baseline_predict(train[tr_mask], te), fold, "baseline (distance band x equipment)", rows)
        for name, cols in VARIANTS.items():
            model = RateModel(features=cols, seeds=[0]).fit(feats[tr_mask], train.loc[tr_mask, "rate_per_mile"])
            pred = model.predict_rate(feats[te_mask], te["distance"])
            evaluate(te, pred, fold, name, rows)

    # Random split (NOT used for decisions) - shows how misleading it would be.
    rng = np.random.RandomState(0)
    is_test = rng.rand(len(train)) < 0.2
    for name in ("final (no market_index, no quote_signal)", "+ quote_signal"):
        cols = VARIANTS[name]
        tr_mask = ~is_test & ~train["is_target_outlier"].values
        model = RateModel(features=cols, seeds=[0]).fit(feats[tr_mask], train.loc[tr_mask, "rate_per_mile"])
        pred = model.predict_rate(feats[is_test], train.loc[is_test, "distance"])
        evaluate(train[is_test], pred, "RANDOM 80/20 (reference only)", name, rows)

    results = pd.DataFrame(rows)
    RESULTS_DIR.mkdir(exist_ok=True)
    results.to_csv(RESULTS_DIR / "validation_results.csv", index=False)

    pd.set_option("display.width", 250, "display.max_columns", 20, "display.max_colwidth", 60)
    time_based = results[~results["fold"].str.startswith("RANDOM")]
    summary = (time_based.groupby(["subset", "variant"])[["MAE", "MAPE_%", "MedAPE_%", "RMSE"]]
               .mean().round(2).reset_index())
    summary.to_csv(RESULTS_DIR / "validation_summary.csv", index=False)
    print("\n=== Mean over the 3 time-based folds ===")
    print(summary.to_string(index=False))
    print("\n=== Per fold (clean rows) ===")
    print(results[results["subset"] == "clean rows"].drop(columns="subset").to_string(index=False))


if __name__ == "__main__":
    main()
