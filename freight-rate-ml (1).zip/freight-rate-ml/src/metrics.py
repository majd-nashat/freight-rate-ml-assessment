import numpy as np


def regression_metrics(y_true, y_pred) -> dict:
    y_true, y_pred = np.asarray(y_true, float), np.asarray(y_pred, float)
    abs_err = np.abs(y_true - y_pred)
    ape = abs_err / y_true
    return {
        "MAE": round(float(abs_err.mean()), 1),
        "MAPE_%": round(float(ape.mean() * 100), 2),
        "MedAPE_%": round(float(np.median(ape) * 100), 2),
        "RMSE": round(float(np.sqrt(((y_true - y_pred) ** 2).mean())), 1),
    }
